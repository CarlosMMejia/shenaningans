//Carlos Mejia

import java.util.Random;

class Main {
  public static void main(String[] args) {
    
    Random generator = new Random();
    
    int count = 0;
    int snakeEyes = 0;
    int twos = 0;
    int threes = 0;
    int fours = 0;
    int fives = 0;
    int sixes = 0;
    int number = 10000;
    int die1Value, die2Value;
    
    while (count < number)
    {
      die1Value = generator.nextInt(6)+1;
      die2Value = generator.nextInt(6)+1;
      
      if(die1Value == die2Value)
      {
        switch(die1Value)
        {
          case 1:
            snakeEyes++;
            break;
          case 2:
            twos++;
            break;
          case 3:
            threes++;
            break;
          case 4:
            fours++;
            break;
          case 5:
            fives++;
            break;
          case 6:
            sixes++;
            break;
        }
      }
      count++;
    }
        System.out.println("You rolled snake eyes " + snakeEyes + " times out of " + count + " rolls.");
        System.out.println("You rolled double twos " + twos + " times out of " + count + " rolls.");
        System.out.println("You rolled double threes " + threes + " times out of " + count + " rolls.");
        System.out.println("You rolled double fours " + fours + " times out of " + count + " rolls.");
        System.out.println("You rolled double fives " + fives + "times out of " + count + " rolls.");
        System.out.println("You rolled double sixes " + sixes + "times out of " + count + " rolls.");
    
  }
}